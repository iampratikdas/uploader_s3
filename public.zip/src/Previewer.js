import React, { Component } from 'react';
import AWS from "aws-sdk";
import Uppy from "@uppy/core";
import "@uppy/core/dist/style.css";
import DataTable from 'react-data-table-component';
export default class Previewer extends Component {
    state={setObjectList:'', 
    columns:[
        {
            name: 'File Name',
            selector: row => row.title,
        },
        {
            name: 'Key Id',
            selector: row => row.KeyID,
        },
    ], preview: false
    }
    constructor(props) {
        super(props);
        // configure AWS SDK
        AWS.config.update({
          region: "us-east-2", 
          accessKeyId: "AKIAVHM4SGP54NEC2S5O", 
          secretAccessKey: "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",
        });
        this.s3 = new AWS.S3();
      }
    handleClick=(event)=>{
        if(this.state.preview === false){

            this.s3.listObjects({ Bucket: "oslm-s3-bucket" }, (err, data) => {
                if (err) {
                  console.error('Error listing objects:', err);
                } else {
                  console.log(data.Contents);
                  this.setState({setObjectList: data.Contents, preview: true})
                }
              });
        }else{
            this.setState({ preview: false})
        }
    }
    handleRowClick=(id)=>{
        console.log(id)
    }
    downloadObject = async () => {
        try {
          const s3 = new AWS.S3();
          const bucketName = 'your-bucket-name';
          const { objectKey } = this.props;
    
          // Get the object data
          const objectData = await s3.getObject({ Bucket: bucketName, Key: objectKey }).promise();
    
          // Create a blob from the object data
          const blob = new Blob([objectData.Body]);
    
          // Create a temporary URL for the blob
          const url = URL.createObjectURL(blob);
    
          // Create a link element and trigger a download
          const link = document.createElement('a');
          link.href = url;
          link.download = objectKey;
          link.click();
    
          // Clean up the URL object
          URL.revokeObjectURL(url);
        } catch (error) {
          console.error('Error downloading object:', error);
        }
      };
  render() {
    console.log(this.state.preview)
    let data=[];
    if(this.state.preview){
        let setObjectList= this.state.setObjectList
        console.log(setObjectList)
        setObjectList.forEach(items=>{
            let obj ={};
            obj.title=items.Key;
            obj.KeyID=<p style={{cursor:"pointer"}}onClick={(e)=>this.handleRowClick(items.Owner.ID)}>{items.Owner.ID}</p>;
            data.push(obj);
        })
    }
    return (
        <>
        <button onClick={this.handleClick}>Previewer</button>
        {
            (()=>{
                if(this.state.preview){
                    return(
                        <DataTable
                            columns={this.state.columns}
                            data={data}
                        />
                    )
                }
            })()
        }
        
        </>
    )
  }
}
