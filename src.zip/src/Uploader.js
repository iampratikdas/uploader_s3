import React, { Component } from "react";
import AWS from "aws-sdk";
import Uppy from "@uppy/core";
import "@uppy/core/dist/style.css";

class Uploader extends Component {
  constructor(props) {
    super(props);
    this.state = { selectedFile: null };

    // configure AWS SDK
    AWS.config.update({
      region: "us-east-2", 
      accessKeyId: "AKIAVHM4SGP54NEC2S5O", 
      secretAccessKey: "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",
    });

    this.s3 = new AWS.S3();
  }

  handleFileUpload = () => {
    const file = this.state.selectedFile;

    if (file) {
      // Set the parameters for the S3 upload
      const params = {
        Bucket: "oslm-s3-bucket",
        Key: file.name,
        Body: file,
        ContentType: file.type,
      };

      // Upload the file to S3
      this.s3.upload(params, (err, data) => {
        if (err) {
          console.error("Error uploading file:", err);
          alert(err)
        } else {
          alert(data.Location)
          console.log("File uploaded successfully:", data.Location);
          this.setState({selectedFile: null})
          this.fileInput.value = null
        }
      });
    } else {
      console.error("No file selected");
    }
  };

  handleFileChange = (event) => {
    this.setState({ selectedFile: event.target.files[0] });
  };

  render() {
    return (
      <div>
        <h1>AWS S3 File Uploader</h1>
        <input type="file" onChange={this.handleFileChange}  ref={(input) => (this.fileInput = input)}  />
        <button onClick={this.handleFileUpload}>Upload</button>
      </div>
    );
  }
}

export default Uploader;
