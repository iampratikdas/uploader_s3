import React from 'react';
import styled from 'styled-components';
import {FaTimes} from 'react-icons/fa';
import {FiDownload} from 'react-icons/fi'

const primary_color = '#2820A6'
const secondary_color = '#6C63FF'
const third_color ='#AEA9FF'
const menu_hover_color = '#5EA2BF'
const filter_hover_color = '#6C68BF'

const Section = styled.div`
    align-items: center!important;
    display: flex!important;
`

const FilterCheck = styled.div`
    position: absolute;
    top: 4px;
    right: -8px;
    font-size: 11px;
    width: 12px;
    height: 12px;
    border-style: solid;
    border-width: 1px;
    border-radius: 50%;
    border-color: green;
    background-color: green;
    color: white;
`

const HomeCover = styled.div`
    position: relative;
    background: url(/images/site/home-cover.jpg);
    background-repeat: no-repeat;
    background-size: cover;
    width: 70vw;
    margin: auto;
    padding: 0px;
    height: calc(100vh - 268px);
    margin-top: 68px;
`

const ContactCover = styled.div`
    position: relative;
    background: url(/images/site/contact-cover.jpg);
    background-repeat: no-repeat;
    background-size: cover;
    width: 70vw;
    margin: auto;
    padding: 0px;
    min-height: 300px;
    margin-top: 68px;
`

const PricingCover = styled.div`
    position: relative;
    background: url(/images/site/pricing-cover.jpg);
    background-repeat: no-repeat;
    background-size: cover;
    width: 70vw;
    margin: auto;
    padding: 0px;
    min-height: 300px;
    margin-top: 68px;
`

const AboutCover = styled.div`
    position: relative;
    background: url(/images/site/about-cover.jpg);
    background-repeat: no-repeat;
    background-size: cover;
    width: 70vw;
    margin: auto;
    padding: 0px;
    min-height: 300px;
    margin-top: 68px;
`

const HomeCaption = styled.div`
    position: absolute;
    bottom: 20px;
    left: calc(35vw - 30%);
    width: 60%;
    background: rgba(40, 32, 182, 0.75);
    border-radius: 20px;
    border-style: dashed;
    border-width: 2px;
    border-color: yellow;
    // text-align: center;
    font-size: 22px;
    font-weight: 700;
    color: yellow;
    padding: 25px;
`
const HomeContent = styled.div`
    background-color: white;
    width: 70vw;
    margin: auto;
    padding: 0px;
    min-height: 50px;
    margin-top: 10px;
    text-align: center;
    font-size: 36px;
    letter-spacing: 1px;
    transform-origin: 0 0;
    padding-bottom: 6px;
    font-family: 'Gilroy ExtraBold';
    line-height: 1.25;
`

const CarouselContent = styled.div`
    width: 50%;
    margin-left: 25%;
    border-style: solid;
    border-width: 2px;
    border-color: ${primary_color};
    min-height: 300px;
    margin-bottom: 15px;
    font-size: 18px;
    border-radius: 10px;


`

const InfoCard = styled.div`
    width: 14vw;
    color: #02A3BB;
    font-weight: 800;
    text-align: center;
    float: left;
    font-size: 46px;
    margin-bottom: 10px;
    font-family: 'Gilroy ExtraBold';
`

const SocialIcon = styled.div`
    width: 25px;
    height: 28px;
    padding: 3px;
    margin-right: 3px;
    float: left;
    font-size: 26px;
    color: ${secondary_color};
    cursor: pointer;
`

const FooterCardContent = styled.div`
    color: #02A3BB;
    font-weight: 500;
    float: left;
    font-size: 14px;

    font-family: 'gilroy-light';
    padding-bottom: 20px;
`

const FooterLink = styled.a`
    color: white;
    font-size: 14px;
    text-align: left;
    &:active: {
        color: 'white';
    }
`

const FooterCard = styled.div`
    color: #02A3BB;
    font-size: 20px;
    font-weight: 700;
    text-align: left;
    float: left;
    padding-left: 5px;
    margin-top: 5px;
    
    margin-bottom: 5px;
`

const BannerHolder = styled.div`
    width: 70vw;
    margin: auto;
    padding: 0px;
`
const SiteContent = styled.div`
    position: fixed;
    top: 50px;
    left: 50px;
    background-color: #ffffe0;
    width: calc(100vw - 40px);
    height: calc(100vh - 40px);
    overflow-y: scroll;
    z-index: -1;
`

const RoundButton = styled.div`
    float: right;
    width: 30px;
    height: 27px;
    text-align: center;
    border-style: solid;
    border-color: white;
    border-width: 2px;
    border-radius: 50%;
    background-color: ${secondary_color};
    color: white;
    font-weight: 500;
    margin-right: 15px;
    margin-top: 2px;
    cursor: pointer;
    &:hover {
        background: ${primary_color};
    }
    line-height : 22px;
`

const MenuIconHolder = styled.div`
    padding-left: 12px;
    position: relative;
    padding-top: 5px;
    // width: 50px;
    // height: 100%;
    background-color: transparent;
    color: #EBEBE8;
    float: left;
    cursor: pointer;
    font-size: 24px;
`

const MenuLineExpanded = styled.div`
    height: 40px;
    width: 100%;
    background: linear-gradient(to right,
     ${secondary_color} 25%, #EBEBE8 25% 100%);
    cursor: pointer;
    &:hover {
        background: linear-gradient(to right,
            ${filter_hover_color} 25%, #CBEBE8 25% 100%);
    }
`
const FilterLine = styled.div`
    height: 40px;
    width: 100%;
    background-color: ${third_color};
    cursor: pointer;
    &:hover {
        background-color: ${filter_hover_color};
    }
`
const FilterLineExpanded = styled.div`
    height: 40px;
    width: 100%;
    background: linear-gradient(to right,
     ${third_color} 25%, #FCFCFC 25% 100%);
    cursor: pointer;
    &:hover {
        background: linear-gradient(to right,
            ${filter_hover_color} 25%, #CBEBE8 25% 100%);
    }
`
const MenuLine = styled.div`
    height: 40px;
    width: 100%;
    background-color: ${secondary_color};
    cursor: pointer;
    &:hover {
        background-color: ${menu_hover_color};
    }
`

const MenuDescHolder = styled.div`
    padding-left: 20px;
    padding-top: 10px;
    width: 135px;
    height: 31px;
    background-colr: transparent;
    float: left;
    cursor: pointer;
`

const SiteMenu = styled.div`
    position: fixed;
    font-size: 11px;
    top: 61px;
    left: 0px;
    width: 50px;
    height: calc(100vh - 50px);
    background-color: ${secondary_color};
    border-right: 1px solid #524F91;
`
const SiteMenuExpanded = styled.div`
    position: fixed;
    font-size: 13px;
    top: 62px;
    left: 0px;
    width: 200px;
    border-right: 1px solid #524F91;
    height: calc(100vh - 50px);
    background: linear-gradient(to right,
     ${secondary_color} 25%, #EBEBE8 25% 100%);
    z-index: 1000;
`

const FilterMenu = styled.div`
    position: fixed;
    font-size: 13px;
    top: 50px;
    left: 50px;
    width: 50px;
    height: calc(100vh - 50px);
    background-color: ${third_color};
    border-right: 1px solid #524F91;
`

const FilterMenuExpanded = styled.div`
    position: fixed;
    font-size: 13px;
    top: 62px;
    left: 0px;
    width: 200px;
    border-right: 1px solid #524F91;
    height: calc(100vh - 50px);
    background: linear-gradient(to right,
     ${third_color} 25%, #FCFCFC 25% 100%);
    z-index: 1000;
    
`

const SiteBanner = styled.div`
    height: 42px;
    width: calc(100vw - 15px);
    background-color: ${primary_color};
    position: fixed;
    top: 0px;
    padding: 10px;
    z-index:1;
    display : flex;
    flex-direction : row;
    justify-content : space-between;
    align-items : center;
`

const UserDiv = styled.div`
    width: 35px;
    height: 35px;
    border-style: solid;
    border-color: white;
    border-width: 1px;
    border-radius: 5px;
    background-color: ${secondary_color};
    color: white;
    font-size: 18px;
    margin-right : 15px;
    cursor: pointer;
    display : flex;
    align-items : center;
    justify-content : center;
    box-sizing : border-box;
    &:hover {
        background-color : #060598;
    }
`
const MenuDiv = styled.div`
    width: 35px;
    height: 35px;
    border-style: solid;
    border-color: white;
    border-width: 1px;
    border-radius: 5px;
    background-color: ${secondary_color};
    color: white;
    font-size: 18px;
    margin-left: 15px;
    cursor: pointer;
    display : flex;
    align-items : center;
    justify-content : center;
    box-sizing : border-box;
    &:hover {
        background-color : #060598;
    }
`

const CreditDiv = styled.div`
    width: 180px;
    height: 30px;
    text-align: center;
    border-style: solid;
    border-color: white;
    border-width: 1px;
    border-radius: 5px;
    background-color: ${secondary_color};
    color: white;
    font-size: 16px;
    font-weight: 500;
    margin-right: 15px;
    cursor: pointer;
    line-height : 30px;    
`

const ButtonDiv = styled.div`
    width: 180px;
    height: 30px;
    text-align: center;
    border-style: solid;
    border-color: white;
    border-width: 1px;
    border-radius: 5px;
    background-color: ${secondary_color};
    color: white;
    font-size: 16px;
    font-weight: 500;
    margin-right: 15px;
    cursor: pointer;
    line-height : 30px;
    &:hover {
        background-color : #060598;
    }
`
const LinkDiv = styled.div`
    float: right;
    min-width: 100px;
    height: 22px;
    text-align: center;
    border-style: solid;
    border-color: white;
    border-width: 1px;
    border-radius: 5px;
    background-color: ${primary_color};
    color: white;
    font-size: 14px;
    font-weight: 700;
    margin-right: 5px;
    padding-top: 3px;
    padding-left: 5px;
    margin-top: 12px;
    cursor: pointer;
    &:hover {
        background-color: ${menu_hover_color};
    }
`
const SearchDiv = styled.div`
    float: left;
    margin-left: 20px;
    width: 180px;
    height: 30px;
    text-align: center;
    border-style: solid;
    border-color: white;
    border-width: 1px;
    border-radius: 5px;
    background-color: ${secondary_color};
    color: white;
    font-size: 16px;
    font-weight: 500;
    margin-right: 5px;
    padding-top: 1px;
    padding-left: 5px;
    margin-top: 2px;
    cursor: pointer;
`

const Container = styled.div`
    width: 100%;
    height: auto;
    padding-top: 40px;
    color: #575962;
`

const Cell = styled.div`
    float left;
    width: 50%;
    @media only screen 
      and (max-device-width: 1024px) {
        width: 100%;
        display: flex;
        justify-content: center;
    }
`

const Image = styled.img`
    float: left;
    margin-left: 130px;
    box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
    @media only screen 
      and (max-device-width: 1024px) {
        height: 200px;
        width: auto;
    }
`

const PriceImage = styled.img`
    margin-left: 15%;
    margin-top: 5%;
    box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
`

const Card = styled.div`
    float left;
    text-align: center;
    margin-top: 30px;
    position: relative;
    display: -ms-flexbox;
    display: flex;
    -ms-flex-direction: column;
    flex-direction: column;
    min-width: 0;
    word-wrap: break-word;
    background-color: #fff;
    background-clip: border-box;
    border: 1px solid rgba(0,0,0,.125);
    border-radius: .25rem;
    box-shadow: 0 .5rem 1rem rgba(0,0,0,.15)!important;
    box-sizing: border-box;
    padding-bottom: 30px;
    padding-left: 30px;
    padding-right: 30px;
    width: calc(70% - 10px);
    @media only screen 
      and (max-device-width: 1024px) {
        width: 100%;
    }
`

const CheckBox = styled.input`
    box-sizing: border-box;
    float: left;
    width: 30px;
    padding: 0;
    margin-top: 15px ! important;
`
const LeadCheckBox = styled.input`
    box-sizing: border-box;
    float: left;
    width: 30px;
    padding: 0;
`
const LeadsInput = styled.input`
    
    padding-left: 5px;
    display: block;
    width: 95%;
    padding: .375rem .75rem;
    font-size: 1.5rem;
    height: 35px;
    font-weight: 400;
    line-height: 1.5;
    color: #495057;
    background-color: #fff;
    background-clip: padding-box;
    border: 1px solid #ced4da;
    // border-radius: 2rem;
    transition: border-color .15s ease-in-out,box-shadow .15s ease-in-out;
`

const LeadsSelect = styled.select`
    padding-left: 5px;
    display: block;
    width: 100%;
    padding: .375rem .75rem;
    font-size: 0.9rem;
    height: 40px;
    font-weight: 400;
    line-height: 1.5;
    color: #495057;
    background-color: #fff;
    background-clip: padding-box;
    border: 1px solid #ced4da;
    border-radius: .25rem;
    transition: border-color .15s ease-in-out,box-shadow .15s ease-in-out;
`

const LeadsTextareaInput = styled.textarea`
    height: 90px;
    width: 95%;
    border: 1px solid #ffffff;
    border-radius: 3px;
    box-shadow: 0 0 4px #c4c4c4;
    padding: 5px;
    color: ${secondary_color};
    font-size: 15px;
`;

const Label = styled.div`
    margin-top: 5px;
    margin-bottom: 5px;
    font-weight: 600;
    font-size: 14px;
    white-space: nowrap;
    text-align: left;
    text-transform: capitalize;
`
const DetailLabel = styled.div`
    margin-top: 2px;
    margin-bottom: 2px;
    font-weight: 500;
    font-size: 14px;
    white-space: nowrap;
    text-align: left;
    text-transform: capitalize;
    font-family: gilroy-light;
`
const CardTitle = styled.div`
    margin: 0;
    padding-top: 0px;
    color:${secondary_color};
    font-size: 20px;
    font-weight: 600;
    line-height: 1.6;
    margin-bottom: 15px;
`

const FormTitle = styled.div`
    position: relative;
    padding-top: 10px;
    width: 100%;
    color: ${secondary_color};
    font-size: 24px;
    font-weight: 400;
    line-height: 1.6;
    text-align: center;
    margin-bottom: 15px;
`

const FormClose = styled.div`
    position: absolute;
    top: 5px;
    right: 15px;
    width: 25px;
    height: 25px;
    font-size: 16px;
    font-weight: 700;
    padding: 5px;
    cursor: pointer;
`

const SubmitButton = styled.button`
    margin-top: 15px;
    height: 35px;
    text-align: center;
    vertical-align: middle;
    cursor: pointer;
    -webkit-user-select: none;
    -moz-user-select: none;
    -ms-user-select: none;
    user-select: none;
    background-color: ${secondary_color};
    border: 1px solid transparent;
    padding: 5px 10px;
    font-size: 18px;
    color: white;
    line-height: 1.5;
    border-radius: 4px;
    margin-bottom: 20px;
`

const ClearFloat = styled.div`
    clear: both;
`

const Logo = styled.img`
    height: 30px;
`

const RightDiv = styled.div`
    width: 20px;
    height: 30px;
    float: right;
    padding-top:3px;
`

const MRButton = styled.button`
    box-sizing: border-box;
    background-color: #37ada7;
    color: #ffffff;
    border: 1px solid #37ada7;
    width: 95px;
    font-size: 13px;
    height: 25px;
    border-radius: 0px;
    margin-right:1px;
`;
const HeaderText = styled.div`
    margin-left: 5px;
    margin-top: 10px;
    margin-bottom: 10px;
    color: #1B1858;
    font-weight: 600;
    letter-spacing: 1px;
`;
const TableHeaderIcon = styled.div`
    float: left;
    margin-right: 10px;
    margin-top: 2px;
    color: #fff;
`;

const TextPara = styled.div`
    padding: 15px 15px 15px 15px;
    color: #c0c0c0;
`
const TableContainer = styled.div`
    background-color: #ffffff;
    padding-bottom: 15px;
    margin-top: 23px;
`
const ExportButton = styled.button`
    box-sizing: border-box;
    background-color: #213E61;
    color: #F2F2F2;
    border: 1px solid #213E61;
    width: 125px;
    font-size: 14px;
    height: 32px;
    border-radius: 5px;
    margin: 12px;
    cursor: pointer;
`;

const CancelButton = styled.button`
    box-sizing: border-box;
    background-color: white;
    color: ${secondary_color};
    border: 1px solid #213E61;
    width: 125px;
    font-size: 14px;
    height: 32px;
    border-radius: 5px;
    margin: 8px;
    cursor: pointer;
`;

const SaveButton = styled.button`
    box-sizing: border-box;
    background-color: ${secondary_color};
    color: white;
    border: 1px solid #213E61;
    width: 125px;
    font-size: 14px;
    height: 32px;
    border-radius: 5px;
    margin: 8px;
    cursor: pointer;
`;

const ModalContainer = styled.div`
    position: relative;
    top: 120px;
    left: 30vw;
    width: 55vw;
    height: 60vh;
    background-color: white;
    border-style: solid;
    border-width: 1px;
    box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
    border-color: ${secondary_color};
    border-radius: 10px;
    //overflow: hidden;
`

const GridContainer = styled.div`
    padding-top: 50px;
    grid-template-columns: repeat(4, 1fr);
    display: grid;
    padding-left: 20px;
    padding-right: 20px;
`
const TopHeader = styled.div`
    position: fixed;
    top: 0px;
    background-color: #2820A6;
    height: 50px;
    width: 100%;
    color: white;
    font-size: 30px;
    padding-left: 15px;
    padding-right: 15px;
    margin-top: 0px;
    margin-bottom: 0px;
    position: fixed;
    border: solid black;
`
const ContainerBody = styled.div`
    width: 100%;
    color: #575962;
`

const Box = styled.div`
    float left;
    text-align: center;
    margin-top: 30px;
    display: -ms-flexbox;
    display: flex;
    -ms-flex-direction: column;
    flex-direction: column;
    min-width: 0;
    word-wrap: break-word;
    background-color: #fff;
    background-clip: border-box;
    border: 1px solid rgba(0,0,0,.125);
    border-radius: .25rem;
    box-shadow: 0 .5rem 1rem rgba(0,0,0,.15)!important;
    box-sizing: border-box;
    padding-bottom: 30px;
    padding-left: 30px;
    padding-right: 30px;
    width: calc(70% - 10px);
    @media only screen 
      and (max-device-width: 1024px) {
        width: 100%;
    }
`

const ElementorWidgetWrap = styled.div` 
    display: flex;
    justify-content: left;
    align-items: left;
    width: 70%;
    margin-left: 300px !important;
    color: #091D30;
    font-size: 40px;
    font-weight: 800;
    line-height: 55px;
`

const ElementorWidgetContainer = styled.div`
    display: flex;
    justify-content: left;
    align-items: left;
    width: 70%;
    margin-left: 300px !important;
    color: #69727A;
    line-height: 27px;
    font-weight: 500;
    font-size: 20px;
    margin-top: 20px;
    padding-right: 270px;
`

const ElementorWidgetWrapTwo = styled.div`
    display: flex;
    justify-content: left;
    align-items: left;
    width: 70%;
    color: #00A2BB;
    font-size: 25px;
    font-weight: 600;
    line-height: 70px;
`

const ElementorWidgetContainerTwo = styled.div`
    display: flex;
    justify-content: left;
    align-items: left;
    width: 70%;
    line-height: 27px;
    marginTop: 20px;
    padding-right: 100px;
    color: #091D30;
    font-size: 25px;
    font-weight: 800;
    line-height: 46px;
`

const HorizontalRule = styled.div`
    border-bottom: 1px solid #DEE8EB;
    width: 100%;
`

const ElementorWidgetWrapThree = styled.div`
    display: flex;
    justify-content: left;
    align-items: left;
    width: 70%;
    margin-left: 300px !important;
    color: #00A2BB;
    font-size: 25px;
    font-weight: 700;
    line-height: 70px;
`

const ElementorWidgetContainerThree = styled.div`
    display: flex;
    justify-content: left;
    align-items: left;
    width: 70%;
    margin-left: 300px !important;
    color: #091D30;
    font-size: 25px;
    font-weight: 800;
    line-height: 46px;
    padding-right: 150px;
`

const AboutPara = styled.div`
    display: flex;
    width: 65%;
    margin-left: 300px !important;
    color: #69727A;
    line-height: 27px;
    font-weight: 500;
    font-size: 20px;
    margin-top: 20px;
`

const FindSolution = styled.div`
    display: flex;
    justify-content: center;
    align-items: center;
    color: #000000;
    font-weight: 900;
    margin-top: 30px;
`

const PricingPage = styled.div`
    display: flex;
    justify-content: center;
    align-items: center;
    font-weight: 900;
    color: #000000;
`

const PricePageLink = styled.a`
    margin-left: 10px;
`

const MessageOne = styled.div`
    color: #000000;
    width: 50%;
    margin-left: 25%;
`
const MessageTwo = styled.div`
    
`

const LearnMore = styled.a`
    margin-left: -1px;
    font-weight: bold;
    margin-top: 35px !important;
    text-decoration: none;
    color: #00A2BB;
`

const LabelList = styled.ul`
    list-style-type: circle;
`
const LeadsNumberInput = styled.input`
    padding-left: 5px;
    display: block;
    width: 95%;
    padding: .375rem .75rem;
    font-size: 1.5rem;
    height: 35px;
    font-weight: 400;
    line-height: 1.5;
    color: #495057;
    background-color: #fff;
    background-clip: padding-box;
    border: 1px solid #ced4da;
    border-radius: .25rem;
    transition: border-color .15s ease-in-out,box-shadow .15s ease-in-out;
`
const LeadsRadioInput = styled.input`
    padding-left: 5px;
    display: block;
    line-height: 1.5;
    color: #495057;
    background-color: #fff;
    background-clip: padding-box;
    border: 1px solid #ced4da;
    border-radius: .25rem;
    transition: border-color .15s ease-in-out,box-shadow .15s ease-in-out;
`

export {FilterCheck, MenuDiv, Section, SiteMenu, SiteMenuExpanded, SiteContent, RightDiv, SearchDiv, CreditDiv, UserDiv, SiteBanner, Container, 
        ClearFloat, SubmitButton, Image, Card, CardTitle, Label, CheckBox, LeadsInput, Cell, Logo,
        MenuIconHolder, MenuLine, MenuDescHolder, MenuLineExpanded, FilterLineExpanded, FilterLine,
        FilterMenuExpanded, FilterMenu, MRButton, ExportButton, HeaderText, TableHeaderIcon, TextPara, TableContainer,
        ModalContainer, FormTitle, LeadsTextareaInput, FormClose, CancelButton, SaveButton, RoundButton, GridContainer, TopHeader,
        ContainerBody, Box, ElementorWidgetWrap, ElementorWidgetContainer, ElementorWidgetWrapTwo, ElementorWidgetContainerTwo, HorizontalRule, 
        ElementorWidgetWrapThree, ElementorWidgetContainerThree, AboutPara, FindSolution, PricingPage, PricePageLink, PriceImage, MessageOne, MessageTwo,
        LearnMore, BannerHolder, HomeCover, HomeContent, HomeCaption, LeadCheckBox, InfoCard, LabelList, LinkDiv, ContactCover, PricingCover, AboutCover,
        FooterCardContent, FooterCard, FooterLink, LeadsNumberInput, SocialIcon, CarouselContent, DetailLabel, LeadsRadioInput, LeadsSelect, ButtonDiv
}