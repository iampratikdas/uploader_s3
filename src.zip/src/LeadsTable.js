import React from "react";
import styled from "styled-components";
// import { FaPlus, FaFileExcel } from "react-icons/fa";
import ReactTable from "react-table";
import "react-table/react-table.css";
import Pagination from "./Pagination.js";
import * as S from "./LeadsComponents.js";
// import Store from "./Store";
// import EventBus from "./EventBus";

import "./table_styles.css";

class LeadsTable extends React.Component {
  state = {
    view_count: 0,
    has_filter: false,
  };

  constructor(props) {
    super(props);
    this.reactTable = React.createRef();
    console.log(this.reactTable)
  }

  componentDidMount = () => {
 
    this.onTableViewChange();
    this.setState({ view_count: this.state.view_count + 1 });
  };
  componentDidUpdate(prevProps) {
    if (prevProps !== this.props) {
      // this.onTableViewChange()
      this.setState({ view_count: this.state.view_count + 1 });
    }
  }

  filterMethod = (filter, row, column) => {
    const id = filter.pivotId || filter.id;
    // console.log('id',id);
    console.log(
      "filter====>",
      row[id] !== undefined ? String(row[id]).includes(filter.value) : true
    );
    // return row[id] !== undefined ? String(row[id]).includes(filter.value) : true
  };

  exportToCSV = () => (event) => {
   
  };

  onTableViewChange = () => {
    const current = this.reactTable.current;
    if (current) {
      const page = current.state.page;
      const pageSize = current.state.pageSize;
      const allData = current.getResolvedState().sortedData;
      const startIdx = page * pageSize;
      const currentData = allData
        .slice(startIdx, startIdx + pageSize)
        .map((item) => item._original);

      // console.log('currentData====>',current);
      // Store.updateStore('filtered_List', allData);
      if (
        this.props.headerText === "My Leads" ||
        this.props.headerText === "My Campaigns"
      ) {
        if ("check_All" in this.props && currentData.length > 0) {
          this.props.getPageData({
            allData: allData,
            currentData: currentData,
          });

          // Store.updateStore('filter_leads', has_filer:true);
        }
      } else {
        if (currentData.length > 0) this.props.getPageData(allData);
      }
    }
  };

  unlockLeads = (selected_leads) => {
    let f_records = [];
    let currentRecords = this.reactTable.current;
    console.log("selected leads count:", selected_leads, currentRecords);
    if (currentRecords !== null) {
      let records = currentRecords.getResolvedState().sortedData;
      if (records.length !== 0) {
        for (let r of records) {
          f_records.push(r._original.id);
        }
      }
      console.log("currentRecords:", records);
    }
  };

  filter_count_compare = (selected_leads) => {
    let currentRecords = this.reactTable.current;
    let event_filter = {};
    if (currentRecords !== null) {
      let records = currentRecords.getResolvedState().sortedData;
      console.log(
        "viewCount leadsTable",
        this.props.viewCount,
        records.length,
        records
      );
      if (this.props.viewCount >= records.length) {
        event_filter.has_filter = true;
      } else {
        event_filter.has_filter = false;
      }
      event_filter.length = records.length;
      event_filter.selected_leads = records;
      event_filter.view_count = this.props.viewCount;
      event_filter.selected_leads_count = Object.keys(selected_leads).length;
      // this.props.has_filter(event_filter)
      console.log("filter_count_compareselected_leads", event_filter);
    //   EventBus.raiseEvent("count_filters", event_filter);
    }
  };
  onColumnFiltersChange = (tag, filter) => {
    console.log("pppppppppp ", filter);
    // Store.updateStore("current_table_filters", filter);
    // EventBus.raiseEvent('current_table_filters',filter)
    const current = this.reactTable.current;
    if (current) {
      const filteredData = current.getResolvedState().sortedData;
      let event_filter = {};
      // let filterData=filteredData.filter(item=>{

      //     let p =item.filter.id
      //     return p.toString().includes(filter.value)
      // })
      event_filter.has_filter = true;
      event_filter.selected_leads = filteredData;
      event_filter.length = filteredData.length;
    }
  };
  render() {
      let tableData = this.props.processData();
      console.log("current=this.props==>",tableData);
    let row_count = tableData.row_count;
    return (
      <S.TableContainer>
      
        <S.ClearFloat />

        <div style={{ marginTop: "5px", width: "100%" }}>
          <ReactTable
            ref={this.reactTable}
            onPageChange={this.onTableViewChange}
            onPageSizeChange={this.onTableViewChange}
            onSortedChange={this.onTableViewChange}
            PaginationComponent={Pagination}
            showPaginationTop={true}
            showPageSizeOptions={true}
            pageSizeOptions={[50, 100, 500]}
            data={tableData.data}
            columns={tableData.columns}
            defaultPageSize={this.props.tableRows}
            filterable={true}
          />
        </div>
        {(() => {
          if (
            "export" in this.props &&
            this.props.export === true &&
            tableData.data.length > 0
          ) {
            return (
              <S.ExportButton onClick={this.exportToCSV()}>
                Export
              </S.ExportButton>
            );
          }
        })()}
      </S.TableContainer>
    );
  }
}

export default LeadsTable;
